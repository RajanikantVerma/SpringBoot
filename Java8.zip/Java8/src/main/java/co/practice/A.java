package co.practice;

public class A {
	public static void main(String[] args) {
		ChildParctice xyz = new ChildParctice();
		xyz.prachi(10);
	}
}
class ParentPractice{
	public void prachi(int x) {
		System.out.println("Printing :" +x);
	}
}
class ChildParctice extends ParentPractice{
	@Override
	public void prachi(int x) {
		super.prachi(x);
		System.out.println("Printing Java :"+x);
	}
} 