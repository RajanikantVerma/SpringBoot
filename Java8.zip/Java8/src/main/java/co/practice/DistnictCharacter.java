package co.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DistnictCharacter {
	public static void main(String[] args) {
		
		/*  Java 7
		 * String s = "prachihira";
		 * StringBuilder sb = new StringBuilder(); for (int i = 0; i < s.length(); i++)
		 * { String s1 = Character.toString(s.charAt(i)); if
		 * (!sb.toString().contains(s1)) { sb.append(s1); } }
		 * System.out.println(sb.toString());
		 */
		// Java 8
		String s = "Download JDK 8 a development environment for building applications and components using the "
				+ "Java programming language components using the Java programming language hehehe rajanikant the development";
		List<String> list = Arrays.asList(s.split(" "));
		List<String> list1 = new ArrayList<String>();
	}
}