package co.practice;

interface One{
	int x =9;
}
interface Two{
	int x=10;
}
public class InterfaceProblem implements One,Two{
static int x =0;
	public static void main(String[] args) {
		System.out.println(x);
	}
}