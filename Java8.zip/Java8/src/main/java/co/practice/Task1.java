package co.practice;

import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Task1 {
	
	public static void main(String[] args) throws IOException {

		String inputHTMLTags = new String("<parent1>\r\n" + 
				"<parent2>\r\n" + 
				"<child1/>\r\n" + 
				"<child2/>\r\n" + 
				"<child3> \r\n" + 
				"</child3>\r\n" + 
				"</parent2>\r\n" + 
				"<parent3>\r\n" + 
				"<child11/>\r\n" + 
				"<child22/>\r\n" + 
				"<child33> \r\n" + 
				"<grandchild44>\r\n" + 
				"</grandchild44>\r\n" + 
				"</child33>\r\n" + 
				"</parent3>\r\n" + 
				"</parent1>");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1 to enter the line number or 2 to enter the tag name:");
		int userInput1 = sc.nextInt();
		
		switch(userInput1) {
			case 1:
				System.out.println("Enter the line number:");
				int lineNumber = sc.nextInt();
				findchildUsingLineNumber(inputHTMLTags, lineNumber);
				break;
			case 2:
				System.out.println("Enter the tag name:");
				sc.nextLine();
				String tagName = sc.nextLine();
				findchildUsingTagName(inputHTMLTags, tagName);
				break;
			default:
					System.out.println("Invalid Option at Switch");
		}
	}

	public static void findchildUsingLineNumber(String inputHTMLTags, int lineNumber) {

		ArrayList<String> child = new ArrayList<String>();
		inputHTMLTags = inputHTMLTags.replaceAll("<", "").replaceAll(">", "").replaceAll("/", "").replaceAll(" ","");
		List<String> parents = Arrays.asList(inputHTMLTags.split("\r\n"));
        String parent= parents.get(lineNumber-1);
        int lastIndex = parents.lastIndexOf(parent);
        for(int i=lineNumber;i<lastIndex;i++) {
        	if(!child.contains(parents.get(i))) {
        		child.add(parents.get(i));
        	}
        }
		System.out.println("Output: "+child);
	}

	public static void findchildUsingTagName(String inputHTMLTags, String tagName) {

		ArrayList<String> child = new ArrayList<String>();
		inputHTMLTags = inputHTMLTags.replaceAll("<", "").replaceAll(">", "").replaceAll("/", "").replaceAll(" ","");
		List<String> parents = Arrays.asList(inputHTMLTags.split("\r\n"));
        int lineNumber= parents.indexOf(tagName);
        int lastIndex = parents.lastIndexOf(tagName);
        for(int i=lineNumber;i<lastIndex;i++) {
        	if(!child.contains(parents.get(i))) {
        		child.add(parents.get(i));
        	}
        }
		System.out.println("Output: "+child);
	}

}