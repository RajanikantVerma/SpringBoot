package co.practice;

public class Bike extends TwoWheeler{
	
	public int x = 15;
	@Override
	public void print() {
		System.out.println("x : "+x);
		super.print();
	}
	public static void main(String[] args) {
		Bike bike = new Bike();
		bike.print();
	}
}