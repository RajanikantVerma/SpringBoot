package co.practice;

public class TwoWheeler {
	
	public int x = 10;
	public void print() {
		System.out.println("super x : "+x);
	}
}