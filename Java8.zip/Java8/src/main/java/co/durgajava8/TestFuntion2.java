package co.durgajava8;
@FunctionalInterface
public interface TestFuntion2 {
	 void m1();
	public static void test1() {
		System.out.println("Test static interface main method");	
	}
	
	default void test2() {
		System.out.println("Test default interface main method");	
	}
}