package co.durgajava8;

class myThread implements Runnable{
	public void run() {
		for(int i=0;i<=10;i++) {
			System.out.println("Child thread");
		}
	}
}

public class ThreadExample {
	public static void main(String[] args) {
		Runnable r = new myThread();
		Thread t = new Thread(r);
		t.start();
		Runnable rt = ()-> {for(int i=0;i<=10;i++) {
			System.out.println("Child thread Java 8");
		}};
		Thread tt = new Thread(rt);
		tt.start();
		for(int i=0;i<=10;i++) {
			System.out.println("Main thread");
		}
	}
}