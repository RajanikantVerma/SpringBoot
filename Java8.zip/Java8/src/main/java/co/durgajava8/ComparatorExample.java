package co.durgajava8;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class myComp implements Comparator<Integer>{
	@Override
	public int compare(Integer o1, Integer o2) {
		if(o2>o1)
			return 1;
		else if(02<o1)
			return -1;
		return 0;
	}
}
public class ComparatorExample {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(1,347,23,4748,78,79);
		Collections.sort(list);
		System.out.println(list);
		
		Comparator<Integer> cmp = (o1,o2)->  {
			if(o2>o1)
				return 1;
			else if(02<o1)
				return -1;
			return 0;
		};
		Collections.sort(list,cmp);
		System.out.println(list);
	}
}