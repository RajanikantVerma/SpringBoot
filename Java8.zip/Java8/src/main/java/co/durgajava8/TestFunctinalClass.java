package co.durgajava8;

public class TestFunctinalClass implements TestFunctional,TestFuntion2{

	public static void main(String[] args) {
		TestFunctional.test1();
		TestFuntion2.test1();
		TestFunctinalClass c = new TestFunctinalClass();
		c.m1();
		c.test2();
		System.out.println("hiareyouhuneeegry".equals("hiareyouhungry") +": hiareyouhungry");
	}
	

	@Override
	public void m1() {
		System.out.println("m1");
		
	}


	@Override
	public void test2() {
		System.out.println("in test 2 main");
	}
}