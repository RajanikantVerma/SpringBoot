package com.learn.limitsservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.limitsservice.bean.LimitsConfigation;
import com.learn.limitsservice.configration.Configuration;

@RestController
public class LimitsConfigurationController {
	
	@Autowired
	private Configuration configuration;

	@GetMapping("/limits")
	public LimitsConfigation reteriveLimitsFromConfigation() {
		return new LimitsConfigation(configuration.getMaximum(), configuration.getMinimum());
	}
}