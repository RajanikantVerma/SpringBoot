package headfirst.designpatterns.command.simpleremoteWL;

@FunctionalInterface 
public interface Command {
	public void execute();
}
