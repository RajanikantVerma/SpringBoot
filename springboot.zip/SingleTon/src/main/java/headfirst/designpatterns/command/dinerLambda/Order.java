package headfirst.designpatterns.command.dinerLambda;

@FunctionalInterface
public interface Order {
	public void orderUp();
}
