package design.pattern.observerPattern.UsingSwimg;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class SimpleObserverUsingSwimg {
	JFrame frame;
	
	public static void main(String[] args) {
		SimpleObserverUsingSwimg subject = new SimpleObserverUsingSwimg();
		subject.go();
	}
	public void go() {
		frame = new JFrame();
		JButton button = new JButton("Should i move on?");
		button.addActionListener(event -> System.out.println("Don't Move!! You should try once more"));
		button.addActionListener(event -> System.out.println("Move on!!, They already Forgot you!!"));
		frame.getContentPane().add(BorderLayout.CENTER, button);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(BorderLayout.CENTER, button);
		frame.setSize(400,400);
		frame.setVisible(true);
	}
}