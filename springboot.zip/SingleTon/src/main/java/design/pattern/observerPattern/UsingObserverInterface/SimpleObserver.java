package design.pattern.observerPattern.UsingObserverInterface;

import java.util.Observable;
import java.util.Observer;

public class SimpleObserver implements Observer {
	public String value;
	Observable observable;
	
	public SimpleObserver(Observable observable) {
		this.observable = observable;
		observable.addObserver(this);
	}

	@Override
	public void update(Observable o, Object arg) {
		System.out.println(arg);
		this.value = (String) arg;
		display();
		if (o instanceof SimpleObservable) {
			SimpleObservable simpleSubject = (SimpleObservable)o;
			this.value = simpleSubject.getValue();
			display();
		}
	}
	
	public void display() {
		System.out.println("SimpleObserver : "+value);
	}
}