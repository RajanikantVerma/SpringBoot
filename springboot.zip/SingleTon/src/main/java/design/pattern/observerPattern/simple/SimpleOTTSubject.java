package design.pattern.observerPattern.simple;

import java.util.ArrayList;
import java.util.List;

public class SimpleOTTSubject implements OTTSubject {

	List<OTTObserver> observers;
	String value;

	public SimpleOTTSubject() {
		observers = new ArrayList<OTTObserver>();
	}

	public void registerOTTObserver(OTTObserver observer) {
		observers.add(observer);
	}

	public void removeOTTObserver(OTTObserver observer) {
		observers.remove(observer);
	}

	public void notifyOTTObserver() {
		for (OTTObserver ottObserver : observers) {
			ottObserver.update(value);
		}
	}

	public void setValue(String value) {
		this.value = value;
		notifyOTTObserver();
	}
}