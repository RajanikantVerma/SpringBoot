package design.pattern.observerPattern.simple;

public class PatternTest {

	public static void main(String[] args) {
		SimpleOTTSubject subject = new SimpleOTTSubject();
		SimpleOTTObserver observer = new SimpleOTTObserver(subject);
		subject.setValue("Panipat");
		subject.registerOTTObserver(observer);
		subject.removeOTTObserver(observer);
		subject.notifyOTTObserver();
	}
}