package design.pattern.observerPattern.UsingObserverInterface;

public class SimpleObserverTest {

	public static void main(String[] args) {
		SimpleObservable subject = new SimpleObservable();
		SimpleObserver observer = new SimpleObserver(subject);
		observer.update(subject, "Rajani");
		subject.addObserver(observer);
	}
}