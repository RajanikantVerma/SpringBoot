package design.pattern.observerPattern.UsingObserverInterface;

import java.util.Observable;

public class SimpleObservable extends Observable {
	private String value;
	
	public SimpleObservable() { }
	
	public void setValue(String value) {
		this.value = value;
		setChanged();
		notifyObservers(value);
	}
	
	public String getValue() {
		return this.value;
	}
}