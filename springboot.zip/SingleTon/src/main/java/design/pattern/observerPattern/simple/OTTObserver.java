package design.pattern.observerPattern.simple;

public interface OTTObserver {
	void update(String webSeriesName);
}
