package design.pattern.observerPattern.simple;

public interface OTTSubject {
	void registerOTTObserver(OTTObserver observer);
	void removeOTTObserver(OTTObserver observer);
	void notifyOTTObserver();
}