package design.pattern.observerPattern.simple;

public class SimpleOTTObserver implements OTTObserver {

	OTTSubject subject;
	String webSeriesName;

	public SimpleOTTObserver(OTTSubject subject) {
		this.subject = subject;
		subject.registerOTTObserver(this);
	}

	public void update(String webSeriesName) {
		this.webSeriesName = webSeriesName;
		display();
	}

	public void display() {
		System.out.println("webSeriesName : " + webSeriesName);
	}
}