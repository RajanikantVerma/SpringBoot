package design.pattern.abstractfactorymethod;

public abstract class Price {
	
	String name;
	int price;
	int quantity;
	
	public abstract int EndUserPrice();
	
	public int priceDescribe() {
		System.out.println("Price Calculation initiallsed");
		System.out.println("name : "+ name +" price per item : " + price +" quantity : "+ quantity );
		int endUserPrice = EndUserPrice();
		System.out.println("Price has been Calculated : "+ EndUserPrice());
		return endUserPrice;
	}
	
	public void printPrice() {
		System.out.println(" data of price has been collected : "+ price * quantity);
	}
	
	public void printperGram() {
		System.out.println(" data of price per gram : "+ price/10);
	}
}