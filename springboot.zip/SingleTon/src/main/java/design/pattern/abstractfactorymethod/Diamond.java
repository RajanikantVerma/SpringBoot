package design.pattern.abstractfactorymethod;

public class Diamond extends Price {
	
	Diamond(){
		name = "Diamond";
		quantity = 1300;
		price = 1234;
	}

	@Override
	public int EndUserPrice() {
		return quantity*price;
	}
}