package design.pattern.abstractfactorymethod;

public class PriceTest {

	public static void main(String[] args) {
		PriceCalculatorFactory factory = new PriceCalculatorFactory();
		PriceMethods methods = new PriceMethods(factory);
		Price price = methods.getCalculatedEnduserPrice("Silver");
		price = methods.getCalculatedEnduserPrice("gold");
	}
}