package design.pattern.abstractfactorymethod;

public class Silver extends Price {
	
	Silver(){
		name = "Silver";
		quantity = 1300;
		price = 1234;
	}

	@Override
	public int EndUserPrice() {
		return quantity*price;
	}
}