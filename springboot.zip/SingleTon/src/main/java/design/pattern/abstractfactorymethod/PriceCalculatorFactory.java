package design.pattern.abstractfactorymethod;

public class PriceCalculatorFactory {
	public Price calculatePrice(String name) {
		switch (name) {
		case "Diamond":
			return new Diamond();
		case "Gold":
			return new Gold();
		default:
			return new Silver();
		}
	}
}