package design.pattern.abstractfactorymethod;

public class PriceMethods {
	
	PriceCalculatorFactory factory;
	PriceMethods(PriceCalculatorFactory factory){
		this.factory = factory;
	}
	
	public Price getCalculatedEnduserPrice(String name) {
		Price price;
		price = factory.calculatePrice(name);
		price.priceDescribe();
		price.printperGram();		
		return price;
	}
}