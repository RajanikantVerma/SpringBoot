package design.pattern.abstractfactorymethod;

public class Gold extends Price {
	
	Gold(){
		name = "Gold";
		quantity = 13;
		price = 51340;
	}

	@Override
	public int EndUserPrice() {
		return quantity*price;
	}
}