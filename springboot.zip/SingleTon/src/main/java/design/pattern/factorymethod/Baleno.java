package design.pattern.factorymethod;

public class Baleno extends Car {
	
	public Baleno(){
		type = "Baleno";
		size = "8 feet";
		marginFromGrund = "10 cm";
		styles.add("size :"+ size);
		styles.add("type :"+ type);
		styles.add("marginFromGrund :"+ marginFromGrund);
	}

}
