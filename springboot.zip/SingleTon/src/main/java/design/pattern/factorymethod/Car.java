package design.pattern.factorymethod;

import java.util.ArrayList;
import java.util.List;

public abstract class Car {
	
	String type;
	String size;
	String marginFromGrund;
	List<String> styles = new ArrayList<>();
	
	public String getType() {
		return type;
	}
	
	public void washing() {
		System.out.println("washing : " + type);
	}
	
	public void service() {
		System.out.println("serviceing : " + type);
	}
	
	public void crushing() {
		System.out.println("crushing : "+ type);
	}

	@Override
	public String toString() {
		return "Car [type=" + type + ", size=" + size + ", marginFromGrund=" + marginFromGrund + ", styles=" + styles.toString()
				+ "]";
	}
}