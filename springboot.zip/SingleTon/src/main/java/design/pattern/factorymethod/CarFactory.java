package design.pattern.factorymethod;

public class CarFactory {
	
	public Car getCar(String name) {
		Car car = null;
		if(name.equalsIgnoreCase("Baleno"))
			car = new Baleno();
		else if(name.equalsIgnoreCase("SUV"))
			car = new SUV();
		else 
			car = new Maruti800();
		return car;
	}
}
