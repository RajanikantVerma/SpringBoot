package design.pattern.factorymethod;

public class SUV extends Car {

	public SUV(){
		type = "SUV";
		size = "9 feet";
		marginFromGrund = "11 cm";
		styles.add("size :"+ size);
		styles.add("type :"+ type);
		styles.add("marginFromGrund :"+ marginFromGrund);
	}
}
