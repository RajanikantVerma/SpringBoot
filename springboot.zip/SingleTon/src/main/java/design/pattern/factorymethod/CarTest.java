package design.pattern.factorymethod;

public class CarTest {

	public static void main(String[] args) {
		CarFactory factory = new CarFactory();
		CarStore store = new CarStore(factory);
		Car car = store.findCar("Baleno");
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		car = store.findCar("delux");
		System.out.println("###########################");
		car = store.findCar("suv");
	}
}