package design.pattern.factorymethod;

public class Maruti800 extends Car {
	
	public Maruti800(){
		type = "Maruti800";
		size = "6 feet";
		marginFromGrund = "8 cm";
		styles.add("size :"+ size);
		styles.add("type :"+ type);
		styles.add("marginFromGrund :"+ marginFromGrund);
	}

}
