package design.pattern.factorymethod;

public class CarStore {
	CarFactory factory;
	public CarStore(CarFactory factory) {
		 this.factory = factory;
	}
	
	public Car findCar(String name) {
		Car car;
		car = factory.getCar(name);
		car.getType();
		car.washing();
		car.crushing();
		car.service();
		return car;
	}
}