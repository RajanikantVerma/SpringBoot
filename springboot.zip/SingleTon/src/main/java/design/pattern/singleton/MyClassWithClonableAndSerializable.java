package design.pattern.singleton;

import java.io.Serializable;

public class MyClassWithClonableAndSerializable implements Cloneable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7015477883433380937L;

	private static MyClassWithClonableAndSerializable instance= null;

	private MyClassWithClonableAndSerializable() {
		// System.out.println("This is MyClassWithClonableAndSerializable");
	}

	public static MyClassWithClonableAndSerializable getInstance() {
		if (instance == null) {
			instance = new MyClassWithClonableAndSerializable();
		}
		return instance;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}