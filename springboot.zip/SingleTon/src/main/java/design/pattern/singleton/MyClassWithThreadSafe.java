package design.pattern.singleton;

public class MyClassWithThreadSafe {
	private static MyClassWithThreadSafe instance;

	private MyClassWithThreadSafe() {
		System.out.println("This is MyClassWithThreadSafe");
	}

	public static synchronized MyClassWithThreadSafe getInstance() {
		if (instance == null)
			instance = new MyClassWithThreadSafe();
		return instance;

	}
}