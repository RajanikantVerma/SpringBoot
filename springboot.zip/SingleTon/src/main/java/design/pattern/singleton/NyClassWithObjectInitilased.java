package design.pattern.singleton;

public class NyClassWithObjectInitilased {
	private static NyClassWithObjectInitilased instance = new NyClassWithObjectInitilased();
	private NyClassWithObjectInitilased() {
		System.out.println("This is NyClassWithObjectInitilased");
	}

	public static NyClassWithObjectInitilased getInstance() {
		return instance;
	}
}