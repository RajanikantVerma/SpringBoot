package design.pattern.singleton;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyClassWithClonableAndSerializableTest {

	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			FileNotFoundException, IOException, CloneNotSupportedException {
		MyClassWithClonableAndSerializable orginalSingletonObject = MyClassWithClonableAndSerializable.getInstance();

		/***
		 * Singleton is broken by using Reflection
		 */
		breakSingletonByReflection(orginalSingletonObject);

		/***
		 * By Serialization/De-Serialization break Singleton We need Serialization
		 * interface in a class nedds to be serialized like Singleton.java
		 */
		breakSingletonByserialization(orginalSingletonObject);

		/***
		 * By Cloning break Singleton We need to implement Cloneable interface
		 */
		breakSingletonByCloning(orginalSingletonObject);

		/***
		 * Break Singleton By thread This scenario is related to multi-threading
		 * environment
		 * 
		 */

		breakSingletonByThreading(orginalSingletonObject);

	}

	private static void breakSingletonByReflection(MyClassWithClonableAndSerializable orginalSingletonObject)
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class<?> singletonClass = Class.forName("design.pattern.singleton.MyClassWithClonableAndSerializable");
		@SuppressWarnings("unchecked")
		Constructor<MyClassWithClonableAndSerializable> constructor = (Constructor<MyClassWithClonableAndSerializable>) singletonClass
				.getDeclaredConstructor();
		constructor.setAccessible(true);
		MyClassWithClonableAndSerializable s = constructor.newInstance();
		printSingletonData("By Reflection", orginalSingletonObject, s);
	}

	private static void breakSingletonByserialization(MyClassWithClonableAndSerializable orginalsingleton)
			throws FileNotFoundException, IOException, ClassNotFoundException {

		/**
		 * Serialization
		 */
		ObjectOutputStream outputStream = new ObjectOutputStream(
				new FileOutputStream("D:\\RV\\Kickoff\\Project\\SingleTon\\src\\main\\resources\\Singleton.ser"));
		outputStream.writeObject(orginalsingleton);
		outputStream.close();

		/**
		 * DeSerialization
		 */
		ObjectInputStream inputStream = new ObjectInputStream(
				new FileInputStream("D:\\RV\\Kickoff\\Project\\SingleTon\\src\\main\\resources\\Singleton.ser"));

		MyClassWithClonableAndSerializable deserializeObject = (MyClassWithClonableAndSerializable) inputStream
				.readObject();
		deserializeObject.hashCode();
		printSingletonData("By Serialization", orginalsingleton, deserializeObject);

	}

	private static void breakSingletonByThreading(MyClassWithClonableAndSerializable orginalSingletonObject) {

		ExecutorService executorService = Executors.newFixedThreadPool(2);
		/**
		 * Run this code snippet after commenting the other code for better
		 * understanding Run it repeatly to create a condition when 2 threads enter the
		 * method getInstance() of Singleton class at a same time When 2 threads enter
		 * the getInstance method at same time they will get the singleton object as
		 * null (private static Singleton singleton in Singleton.java) Then they will
		 * create two different objects ( have different hashcode) in this case
		 * singleton pattern will break.
		 */
		executorService.submit(MyClassWithClonableAndSerializableTest::useSingleton); // JAVA 8 syntax it will get the
																						// singleton instance
		executorService.submit(MyClassWithClonableAndSerializableTest::useSingleton);
		executorService.shutdown();
	}

	public static void useSingleton() {
		MyClassWithClonableAndSerializable singleton = MyClassWithClonableAndSerializable.getInstance();
		printSingletonData("By Threading", singleton);

	}

	private static void breakSingletonByCloning(MyClassWithClonableAndSerializable orginalSingletonObject)
			throws CloneNotSupportedException {
		MyClassWithClonableAndSerializable clonedSingletonObject = (MyClassWithClonableAndSerializable) orginalSingletonObject
				.clone();
		printSingletonData("By Cloning", orginalSingletonObject, clonedSingletonObject);
	}

	public static void printSingletonData(String operationName, MyClassWithClonableAndSerializable orginalsingleton,
			MyClassWithClonableAndSerializable reflectionSigletonObject) {

		System.out.println("------------------------------------------");
		System.out.println("New Operation");
		System.out.println(operationName);
		System.out.println("orginal Hashcode=" + orginalsingleton.hashCode());
		System.out.println("New Object hashcode=" + reflectionSigletonObject.hashCode());
		Boolean value = orginalsingleton.hashCode() != reflectionSigletonObject.hashCode();
		System.out.println("These Object have different hascode. They are two different object Right = " + value);
		System.out.println("As these are different Object this means Singleton Pattern is broken");
	}

	private static void printSingletonData(String operationName, MyClassWithClonableAndSerializable singleton) {
		System.out.println("------------------------------------------");
		System.out.println("New Operation");
		System.out.println(operationName);
		System.out.println("Object hashcode=" + singleton.hashCode());
	}
}