package design.pattern.singleton;

public class MyClass {
	private static MyClass instance;

	private MyClass() {
		System.out.println("This is MyClass");
	}

	public static MyClass getInstance() {
		if (instance == null) {
			instance = new MyClass();
		}
		return instance;
	}
}