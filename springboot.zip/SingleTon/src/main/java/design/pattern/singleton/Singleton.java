package design.pattern.singleton;

import java.io.ObjectStreamException;
import java.io.Serializable;

/*Rule Breakers 

It can break if the class is Serializable
It can break if its 'Clonable`
You can break by Reflection (I believe)
it can break ff multiple classloaders are loaded the class

*How do you solve rule breakers?

It is much safer to do eager initialization
To prevent deserializing to create new object you may override readResolve() method in your class and throw exception
To prevent cloning, you may overrride clone() and throw CloneNotSupported exception
To escape for reflective instantion, we can add check in the constructor and throw exception.*/

public class Singleton implements Cloneable, Serializable {

	private static final long serialVersionUID = -4354259909212072891L;

	private static Singleton instance = new Singleton(); // Eagar initialization

	private Singleton() {
		if (instance != null) {
			throw new IllegalStateException("Singleton already Created");
		}
	}

	public static Singleton getInstance() {
		return instance;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	private Object readResolve() throws ObjectStreamException {
		return instance;
	}

	private Object writeReplace() throws ObjectStreamException {
		return instance;
	}
}