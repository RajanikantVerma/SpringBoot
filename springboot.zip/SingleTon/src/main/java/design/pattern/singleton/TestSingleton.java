package design.pattern.singleton;

public class TestSingleton {
	
	public static void main(String[] args) {
		System.out.println(MyClass.getInstance());
		System.out.println(MyClassWithThreadSafe.getInstance());
		System.out.println(NyClassWithObjectInitilased.getInstance());
		System.out.println(DoubleCheckingMyClass.getInstance());
		MyClassEnum singlteon = MyClassEnum.UNIQUE_INSTANCE;
		System.out.println(singlteon);
		System.out.println(MyClass.getInstance());
		System.out.println(MyClass.getInstance());
	}

}
