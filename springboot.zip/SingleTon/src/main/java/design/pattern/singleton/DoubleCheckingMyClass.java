package design.pattern.singleton;

public class DoubleCheckingMyClass {
	private volatile static DoubleCheckingMyClass instance;

	private DoubleCheckingMyClass() {
		System.out.println("This is DoubleCheckingMyClass");
	}

	public static DoubleCheckingMyClass getInstance() {
		if (instance == null) {
			synchronized (DoubleCheckingMyClass.class) {
				if (instance == null) {
					instance = new DoubleCheckingMyClass();
				}
			}
		}
		return instance;
	}
}