package design.pattern.singleton;

public enum MyClassEnum {
	UNIQUE_INSTANCE;
}