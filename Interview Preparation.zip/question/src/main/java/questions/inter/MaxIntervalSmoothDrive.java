package questions.inter;

import java.util.Arrays;
import java.util.Random;

/**
 * @author rajanikant verma
 * This code has written in consider of 60 min data of speed of card
 * solution is for find out the speed at saturation or accelerating speed with maximum minutes of run
 *
 */
public class MaxIntervalSmoothDrive {

	public static void main(String[] args) {
		int[] array = new Random().ints(60, 0, 60).toArray();
		//int[] array = {25,33,40,40,10,1,47,8,2,2,33,11,21,18,25,27,46,15,50,13,27,26,28,48,27,38,25,48,32,51,45,10,28,9,15,28,48,51,35,24,40,44,4,36,58,18,43,6,5,29,51,2,54,35,52,1,45,2,14,59};
		System.out.println("Elements of Array for 60 minutes");
		Arrays.stream(array).forEach(s -> System.out.print(s + " "));
		int lastIndex = -1;
		int count = 0;
		int max_count = 0;
		for (int i = 0; i < array.length; i++) {
			if (i==0) {
				count = 1;
			} else if (array[i-1] <= array[i]) {
				if(count ==0)
					count++;
				count++;
			}
			else {
				count = 0;
			}
			if (max_count <= count) {
				max_count = count;
				lastIndex = i;
			}
		}
		System.out.println("");
		System.out.println("Printing max saturated speed of car range ");
		int start_index = lastIndex - max_count + 1;
		for (int j = start_index; j <= lastIndex; j++) {
			System.out.print(array[j] + " ");
		}
		System.out.println("");
		System.out.println("Duration in minutes of stauration : " + max_count);
		System.out.println("Initial minutes at which car is starting for saturation : " + start_index
				+ " minutes.  Ending minutes after which car is loose for saturation : " + lastIndex);
	}
}