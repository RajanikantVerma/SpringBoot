package questions.array;

public class ReverseWord {

	public static void main(String[] args) {
		String s = "Hello World!! Its time get rid of corona, What's your thought in this!! although your thought dosen't matter to corona"
				+ " this is so true. Its time to stay safe.";
		String reverseString = "";
		String[] st = s.split(" ");
		for (int i = st.length - 1; i >= 1; i--) {
			if (reverseString.indexOf(st[i]) == -1) {
				if (i == s.length() - 1)
					reverseString = reverseString + st[i];
				else
					reverseString = reverseString + " " + st[i];
			}
		}
		System.out.println(reverseString);
	}
}
