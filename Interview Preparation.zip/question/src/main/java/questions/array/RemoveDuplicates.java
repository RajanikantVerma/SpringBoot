package questions.array;

public class RemoveDuplicates {

	public static void main(String[] args) {
		int[] a = { 1, 23, 45, 67, 9, -1, 0, 6, 47, 45, 9, 67 };
		int a1 = a.length;
		for (int i = 0; i < a1; i++) {
			for (int j = i + 1; j < a1; j++) {
				int tmp = 0;
				if (a[i] > a[j]) {
					tmp = a[i];
					a[i] = a[j];
					a[j] = tmp;
				}
			}
		}
		int[] temp = new int[a1];
		int count =0; 
		for(int i =0;i<a1;i++) {
			if(i!=0 && a[i-1]!=a[i])
				temp[count++] = a[i];
			if(i==0)
				temp[count++]= a[i];
		}
		for (int i =0;i<count;i++) {
			System.out.println(temp[i]);
		}
		
		String[] b = {"test","name","raj","verma","java","", "name", "raj"};
		int a2= b.length;
		for (int i = 0; i < a2; i++) {
			for (int j = i + 1; j < a2; j++) {
				String tmp = "";
				if (b[i].compareTo(b[j])>0) {
					tmp = b[i];
					b[i] = b[j];
					b[j] = tmp;
				}
			}
		}
		
		String[] sortString = new String[a2];
		int count1 =0; 
		for(int i =0;i<a2;i++) {
			if(i!=0 && !b[i-1].equals(b[i]))
				sortString[count1++] = b[i];
			if(i==0)
				sortString[count1++]= b[i];
		}
		for (int i=0; i < count1;i++) {
			System.out.println(sortString[i]);
		}
	}
}