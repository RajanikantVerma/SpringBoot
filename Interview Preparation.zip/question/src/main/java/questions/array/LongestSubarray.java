package questions.array;

import java.util.Map;
import java.util.HashMap;

public class LongestSubarray {

	public static void main(String[] args) {
		int[] A = { 5, 6, -5, 5, 3, 5, 3, -2, 0 };
		int sum = 8;
		findMaxLenSubarray(A, sum);
		findMaxLenSubarrayUsingMap(A, 14);
	}

	private static void findMaxLenSubarrayUsingMap(int[] a, int n) {
		int len = 0;
		int ending_index = -1;
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(0, -1);
		int sum =0;
		for(int i =0; i< a.length;i++) {
			sum += a[i];
			map.putIfAbsent(sum, i);
			if(map.containsKey(sum - n) && len < i- map.get(sum - n )) {
				len = i - map.get(sum - n);
				ending_index = i;
			}
		}
		System.out.println("[" + (ending_index - len + 1) + ", " + ending_index + "]");
	}

	private static void findMaxLenSubarray(int[] a, int n) {
		int len = 0;
		int ending_index = -1;
		for (int i = 0; i < a.length; i++) {
			int sum = 0;
			for (int j = i; j < a.length; j++) {
				sum += a[j];
				if (sum == n && len < j - i + 1) {
					len = j - i + 1;
					ending_index = j;
				}
			}
		}
		System.out.println("[" + (ending_index - len + 1) + ", " + ending_index + "]");
	}
}