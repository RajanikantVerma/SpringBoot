package questions.array;

import java.util.Arrays;

public class SortingUsingRecursion {

	public static void main(String[] args) {
		int[] arr = {1,4,-1,4,99, 45, 34, -23};
		recursingSorting(arr,arr.length);
		System.out.println(Arrays.toString(arr));
		String[] brr = {"raj","name","abc","raj","test","text","specch",null};
		recursiveSorting(brr,brr.length);
		System.out.println(Arrays.toString(brr));
	}

	private static void recursiveSorting(String[] arr, int length) {
		if(length==1)
			return;
		for(int i =1; i<length;i++) {
			String temp ="";
			if(arr[i-1].compareTo(arr[i])>0) {
				temp= arr[i-1];
				arr[i-1]=arr[i];
				arr[i]=temp;
			}
		}
		recursiveSorting(arr,length-1);
	}

	private static void recursingSorting(int[] arr, int length) {
		if(length==1)
			return;
		for(int i =1; i<length;i++) {
			int temp =0;
			if(arr[i-1]>arr[i]) {
				temp= arr[i-1];
				arr[i-1]=arr[i];
				arr[i]=temp;
			}
		}
		recursingSorting(arr,length-1);
	}
}