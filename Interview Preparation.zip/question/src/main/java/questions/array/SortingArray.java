package questions.array;

public class SortingArray {

	public static void main(String[] args) {
		int[] a = { 1, 23, 45, 67, 9, -1, 0, 6, 47, 45, 9, 67 };
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				int tmp = 0;
				if (a[i] > a[j]) {
					tmp = a[i];
					a[i] = a[j];
					a[j] = tmp;
				}
			}
		}
		for (int i : a) {
			System.out.println(i);
		}
		
		String[] b = {"test","name","raj","verma","java","", "name", "raj"};
		for (int i = 0; i < b.length; i++) {
			for (int j = i + 1; j < b.length; j++) {
				String tmp = "";
				if (b[i].compareTo(b[j])>0) {
					tmp = b[i];
					b[i] = b[j];
					b[j] = tmp;
				}
			}
		}
		for (String i : b) {
			System.out.println(i);
		}
	}
}