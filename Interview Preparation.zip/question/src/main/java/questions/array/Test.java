package questions.array;

public class Test {

double d;
float f;
int i;
String s ;
long l;

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	long temp;
	temp = Double.doubleToLongBits(d);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	result = prime * result + Float.floatToIntBits(f);
	result = prime * result + i;
	result = prime * result + (int) (l ^ (l >>> 32));
	result = prime * result + ((s == null) ? 0 : s.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Test other = (Test) obj;
	if (Double.doubleToLongBits(d) != Double.doubleToLongBits(other.d))
		return false;
	if (Float.floatToIntBits(f) != Float.floatToIntBits(other.f))
		return false;
	if (i != other.i)
		return false;
	if (l != other.l)
		return false;
	if (s == null) {
		if (other.s != null)
			return false;
	} else if (!s.equals(other.s))
		return false;
	return true;
}

public static void main(String[] args) {
		Integer i = 5;
		Double d = 5444.899;
		Long l = (long) 78967898;
		Float f  = .89f;
		String s = "raj";
		System.out.println(i.hashCode() + ": i");
		System.out.println(d.hashCode() + ": d");
		System.out.println(l.hashCode() + ": l");
		System.out.println(f.hashCode() + ": f");
		System.out.println(s.hashCode() + ": s");
	}

}
