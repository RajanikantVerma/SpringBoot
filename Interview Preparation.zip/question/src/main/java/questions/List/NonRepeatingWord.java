package questions.List;

public class NonRepeatingWord {

	public static void main(String[] args) {
		String s = "eleplantlegal";
		char[] charArray = s.toCharArray();
		int index =-1;
		for(int i =0;i<charArray.length;i++) {
			if(s.indexOf(charArray[i])==s.lastIndexOf(charArray[i])) {
				index = i;
				break;
			}
		}
		System.out.println(charArray[index]);
	}
}