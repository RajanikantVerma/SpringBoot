package questions.inteface;

public interface TestInterface {

	public static void main(String[] args) {
		System.out.println("In inteface");
	}
}
