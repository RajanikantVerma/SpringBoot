package questions.inteface;

public abstract class TestAbstactClass {
	int a;
	public TestAbstactClass(int a) {
		super();
		this.a = a;
	}

	public abstract void print();

	public static void main(String[] args) {
		System.out.println("I am abstarct");

	}

}
