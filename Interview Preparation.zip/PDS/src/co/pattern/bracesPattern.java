package co.pattern;

import java.util.Stack;

public class bracesPattern {

	public static void main(String[] args) {
		String str1 = "{[({})]})";
		String str2 = "{{([()])}}";
		System.out.println(isBalanced(str1));
		System.out.println(validateUsingStack(str2));
	}
	
    public static String isBalanced(String s) {
        int n = s.length();
            while(n>0){
                s = s.replace("{}","");
                 s = s.replace("[]","");
                  s = s.replace("()","");
                  n--;
            }
            if(s.length()>0)
                 return "NO";
            else
                  return "YES";

    }
    
    public static String validateUsingStack(String s) {
    	Stack<Character> stack = new Stack<>();
    	char[] c = s.toCharArray();
    	for(int i =0; i<s.length() ;i++) {
    		if(c[i]=='{') {
    			stack.push('}');
    		}else if(c[i]=='[') {
    			stack.push(']');
    		}else if(c[i]=='(') {
    			stack.push(')');	
    		}else if(stack.isEmpty() || stack.pop()!=c[i]) {
    			return "NO";
    		}
    	}
    	return stack.isEmpty() ? "YES" : "NO";
    }
}