package co.list;

public class DoublyLinkedListTest {

	public static void main(String[] args) {
		DoublyLinkedList list = new DoublyLinkedList();
		list.insertAtHead(12);
		list.insertAtHead(13);
		list.insertAtHead(16);
		System.out.println(list);
	}

}
