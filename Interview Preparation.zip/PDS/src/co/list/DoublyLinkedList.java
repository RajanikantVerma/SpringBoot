package co.list;

public class DoublyLinkedList {
	
	private DoublyLinkedNode head;
	
	public void insertAtHead(int data) {
		DoublyLinkedNode newNode = new DoublyLinkedNode(data);
		newNode.setNextNode(this.head);
		this.head= newNode;
		if(this.head!=null)
			this.head.setPrvNode(this.head);
	}
	
	@Override
	public String toString() {
		String result = "{";
		
		DoublyLinkedNode current = this.head;
		
		while(current != null) {
			result += current.toString() + ",";
			current = current.getNextNode();
		}
		
		result += "}";
		return result;
	}	

}
