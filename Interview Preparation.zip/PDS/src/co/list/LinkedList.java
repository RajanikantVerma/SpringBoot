package co.list;

public class LinkedList {
	private Node head ;
	public Node getHead() {
		return head;
	}
	public void setHead(Node head) {
		this.head = head;
	}
	
	public void insertAthead(int data) {
		Node newNode = new Node(data);
		newNode.setNextNode(this.head);
		this.head = newNode;
	}
	
	public int length() {
		Node current = this.head;
		int length = 0;
		while(current!= null) {
			length++;
			current = current.getNextNode();
		}
		return length;
	}
	
	public Node get(int data) {
		Node current = this.head;
		while(current!=null) {
			current = current.getNextNode();
			if(current.getData()==data) {
				return current;
			}
		}
		return null;
	}
	
	public void reverse() {
		Node previous = null;
		Node current = this.head;
		Node next;
		while(current!=null) {
			next = current.getNextNode();
			current.setNextNode(previous);
			previous  = current;
			current = next;
		}
		this.head = previous; 
	}
				
	public Node middle() {
		Node current = this.head;
		Node middle = this.head ;
		int length = 0;
		while(current!=null) {
			length++;
			if(length%2==0 && length!=2)
				middle = middle.getNextNode();
			current = current.getNextNode();
		}
		if(length%2==1)
			middle= middle.getNextNode();
		return middle;
	}
	
	public void deleteFromHead() {
			this.head = this.head.getNextNode();
	}

	@Override
	public String toString() {
			String result = "{";
			Node current = this.head;
			while(current!=null) {
				result += current.toString() + " , ";
				current = current.getNextNode();
			}
		
			result += "}";
		return result;
	}
	
	
}