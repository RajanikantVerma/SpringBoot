package co.list;

public class LinkedListTest {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.insertAthead(4);
		list.insertAthead(6);
		list.insertAthead(9);
		System.out.println(list);
		System.out.println(list.get(6));
		list.deleteFromHead();
		list.insertAthead(12);
		System.out.println(list);
		list.reverse();
		list.insertAthead(18);
		System.out.println(list);

		System.out.println(list.middle());
	}
}
