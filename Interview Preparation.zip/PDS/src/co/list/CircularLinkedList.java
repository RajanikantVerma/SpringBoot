package co.list;

public class CircularLinkedList {

	private Node head;
	private Node tail;

	public void insert(int data) {
		Node newNode = new Node(data);
		if (this.head == null)
			this.head = newNode;
		else
			this.tail.setNextNode(newNode);

		this.tail = newNode;
		this.tail.setNextNode(this.head);
	}

	public void delete(int data) {
		Node current = this.head;
		if (current == null)
			return;
		do  {
			Node nextNode = current.getNextNode();
			if (nextNode.getData() == data) {
				if (this.tail == this.head) {
					this.tail = null;
					this.head = null;
				} else {
					current.setNextNode(nextNode.getNextNode());
					if (this.head == nextNode)
						this.head = this.head.getNextNode();
					if (this.tail == nextNode)
						this.tail = current;
				}
				break;
			}
			current = current.getNextNode();
		} while (current != this.head);
	}
	
	public boolean isAvailable(int data) {
		Node current = this.head;
		if(current == null)
			return false;
		do {
			if(current.getNextNode().getData()==data)
				return true;
			current = current.getNextNode();
		} while(current!=this.head);
		return false;
	}

	@Override
	public String toString() {
		String result = "{";
		Node current = this.head;

		do {
			result += current.toString() + " , ";
			current = current.getNextNode();
		} while (this.head != null && current!= this.head);
		result += "}";
		return result;
	}
}
