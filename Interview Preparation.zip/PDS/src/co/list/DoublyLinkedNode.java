package co.list;

public class DoublyLinkedNode {
	private int data;
	private DoublyLinkedNode nextNode;
	private DoublyLinkedNode prvNode;
	
	public DoublyLinkedNode(int data) {
		this.data = data;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	public DoublyLinkedNode getNextNode() {
		return nextNode;
	}

	public void setNextNode(DoublyLinkedNode nextNode) {
		this.nextNode = nextNode;
	}

	public DoublyLinkedNode getPrvNode() {
		return prvNode;
	}

	public void setPrvNode(DoublyLinkedNode prvNode) {
		this.prvNode = prvNode;
	}

	@Override
	public String toString() {
		return "DoublyLinkedNode [data=" + data + "]";
	}
}
