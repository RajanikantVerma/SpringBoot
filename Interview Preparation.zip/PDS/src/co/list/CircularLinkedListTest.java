package co.list;

public class CircularLinkedListTest {

	public static void main(String[] args) {
		CircularLinkedList list = new CircularLinkedList();
		list.insert(4);
		list.insert(8);
		list.insert(19);
		list.insert(29);
		System.out.println(list);
		System.out.println(list.isAvailable(19));
		list.delete(8);
		System.out.println(list);
	}

}
