package co.sort;

public class BinarySearch {
	public static void main(String[] args) {
		//int[] arr = { 1, 3, 4, -4, 8, 10, 12, 23, 45, -456 };
		int[] arr = {1,3,5,7,45,356,567};
		int n = arr.length-1;
		int key = 15;
		int position = sortArray(arr, 0, n, key);
		System.out.println(position ==-1 ? "Not Found" : "Found at : "+ position);
	}

	private static int sortArray(int[] arr, int i, int n, int key) {
		int mid = (i + n) / 2;
		if(i> n)
			return -1;
		else if (n < 1)
			return -1;
		else if (arr[i] == key)
			return i;
		else if (arr[n] == key)
			return n;
		else if (arr[mid] == key)
			return mid;
		// In case of Sorted array
		if (arr[i] <= arr[mid]) {
			if (arr[i] <= key && key <= arr[mid])
				return sortArray(arr, i, mid - 1, key);
			return sortArray(arr, mid + 1, n, key);
		}
		// In case of not sorted array
		if (arr[mid] <= key && key <= arr[n])
			return sortArray(arr, mid+1 , n, key);
		return sortArray(arr, i, mid-1, key);
	}
}