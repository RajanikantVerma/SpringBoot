package co.sort;

import java.util.Arrays;

public class SelectionSort {

	public static void main(String[] args) {
		int[] arr = { 1, -3, 4, 7, -90, 1, 5, 8, 7, -34 };
		int mini =0;
		for(int i=0; i< arr.length-1; i++) {
			mini = i;
			for(int j = i+1 ;j< arr.length; j++) {
				if(arr[mini]>arr[j])
					mini = j;
			}
			int tmp = arr[mini];
			arr[mini] = arr[i];
			arr[i] = tmp;
		}
		Arrays.stream(arr).forEach(System.out::println);
	}

}
