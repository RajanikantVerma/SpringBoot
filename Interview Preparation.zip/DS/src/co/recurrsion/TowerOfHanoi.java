package co.recurrsion;

public class TowerOfHanoi {

	public void move(int noOfDisc, char from, char to, char inter) {
		if (noOfDisc == 1) {
			System.out.println("Moving disc 1 from " + from + " to " + to);
		} else {
			move(noOfDisc - 1, from, inter, to);
			System.out.println("Moving disc " + noOfDisc + " from " + from + " to " + to);
			move(noOfDisc - 1, inter, to, from);
		}
	}

	public static void main(String[] args) {
		TowerOfHanoi tower = new TowerOfHanoi();
		tower.move(4, 'A', 'B', 'C');

	}

}
