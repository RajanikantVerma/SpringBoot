package co.recurrsion;

public class GCP {

	public static int getGCP(int a, int b) {
		if(b==0)
			return a;
		return getGCP(b, a%b);
	}
	public static void main(String[] args) {
		System.out.println(getGCP(334,13435435));
	}

}
