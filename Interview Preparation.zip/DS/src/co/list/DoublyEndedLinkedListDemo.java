package co.list;

public class DoublyEndedLinkedListDemo {
	
	public static void main(String[] args) {
		DoublyEndedLinkedList list = new DoublyEndedLinkedList();
		list.insertAtHead(4);
		list.insertAtTail(5);
		System.out.println(list);
	}

}
