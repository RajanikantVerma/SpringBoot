package co.list;

public class DoublyLinkedListDemo {

	public static void main(String[] args) {
		DoublyLinkedList list = new DoublyLinkedList();
		list.insertAtHead(3);
		list.insertAtHead(4);
		list.insertAtHead(6);
		System.out.println(list);
	}
}