package co.list;

public class Node {
	private int head;
	private Node nextNode;
	public int getHead() {
		return head;
	}
	public void setHead(int head) {
		this.head = head;
	}
	public Node getNextNode() {
		return nextNode;
	}
	public void setNextNode(Node nextNode) {
		this.nextNode = nextNode;
	}
	public Node(int head) {
		this.head = head;
	}
	@Override
	public String toString() {
		return "Data =" + this.head;
	}

}
