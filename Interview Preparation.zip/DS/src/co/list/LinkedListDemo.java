package co.list;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.insertAtHead(4);
		list.insertAtHead(6);
		list.insertAtHead(10);
		list.insertAtHead(16);
		list.insertAtHead(23);
		list.insertAtHead(34);
		list.insertAtHead(45);
		System.out.println(list.toString());
		System.out.println(list.length());
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		System.out.println(list.middleNode().toString());
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		list.deleteFromHead();
		System.out.println(list.toString());
		System.out.println(list.length());
		list.reverse();
		System.out.println(list.toString());
	}
}