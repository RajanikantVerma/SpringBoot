package co.lru;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

public class LRUCache {

	Set<Integer> cache;
	int capacity;
	
	public LRUCache(int capacity) {
		this.capacity = capacity;
		cache = new LinkedHashSet<Integer>(capacity);
	}
	
	public boolean get(int key) {
		if(!cache.contains(key))
			return false;
		cache.remove(key);
		cache.add(key);
		return true;
	}
	
	public void refer(int key) {
		if(!get(key))
			put(key);	
	}
	
	public void put(int key) {
		if(cache.size() == capacity) {
			int firstkey = cache.iterator().next();
			cache.remove(firstkey);
		}
		cache.add(key);
	}
	
	public void display() {
		LinkedList<Integer> list = new LinkedList<>(cache);
		Iterator<Integer> it = list.descendingIterator();
		while(it.hasNext()) {
			System.out.println(it.next()+ " ");
		}
		
	}
	
	public static void main(String[] args) {
		LRUCache lu = new LRUCache(5);
		lu.refer(3);
		lu.refer(6);
		lu.refer(5);
		lu.refer(7);
		lu.refer(8);
		lu.display();
		System.out.println("%%%%%%%%%%%%%%");
		lu.refer(9);
		System.out.println("%%%%%%%%%%%%%%");
		lu.display();
		System.out.println(lu.get(7));
		lu.display();
	}

}
