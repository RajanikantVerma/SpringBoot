package co.lru;

import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

public class LRUCacheUsingDeque {

	private final int capacity;
	private Deque<Integer> doblyque ;
	private HashSet<Integer> set;
	
	public LRUCacheUsingDeque(int capacity) {
		this.capacity = capacity;
		doblyque = new LinkedList<Integer>();
		set =  new HashSet<Integer>();
	}
	
	public void refer(int key) {
		if(!doblyque.contains(key)) {
			if(doblyque.size() == capacity) {
				int last = doblyque.removeLast();
				set.remove(last);
			}
		}else {
			doblyque.remove(key);
		}
		doblyque.add(key);
		set.add(key);
	}
	
	public void display() {
		Iterator<Integer> it = doblyque.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
	
	
	public static void main(String[] args) {
		LRUCacheUsingDeque lu = new LRUCacheUsingDeque(5);
		lu.refer(3);
		lu.refer(6);
		lu.refer(5);
		lu.refer(7);
		lu.refer(8);
		lu.display();
		System.out.println("%%%%%%%%%%%%%%");
		lu.refer(9);
		System.out.println("%%%%%%%%%%%%%%");
		lu.display();

	}

}
